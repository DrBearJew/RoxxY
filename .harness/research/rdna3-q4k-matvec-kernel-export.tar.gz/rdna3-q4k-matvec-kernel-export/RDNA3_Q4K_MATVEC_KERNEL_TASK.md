# RDNA3 Experimental Q4_K Matvec Kernel Task

## Goal

Design and prototype an opt-in RDNA3/gfx1100 single-token decode matvec kernel for `GGML_TYPE_Q4_K` first, then `GGML_TYPE_Q6_K`, to improve target decode/runtime speed for Qwen3.6-27B no-spec generation.

The current requested target path is already route-correct for attention:

```text
fa_final_select: inst=decode_qk selected=rocm_q8k_dot4_kq ... K=i32 V=q4_0
```

But profiling shows attention is not the bottleneck. The bottleneck is regular model weight matvec during autoregressive decode.

## Current Evidence

Canonical server no-spec target decode:

```text
MODE=perf CASES=nospec N_PREDICT=512 CTX_SIZE=2048 BATCH_SIZE=2048 UBATCH_SIZE=1024 CACHE_TYPE_K=f16 CACHE_TYPE_V=q4_0
predicted_per_second ~= 29 tok/s
```

Route proof:

```text
target_route = rocm_q8k_dot4_kq
target_kv    = K=i32 V=q4_0
errors       = none
```

`rocprofv3` kernel-time summary from a 64-token no-spec run:

```text
mul_mat_vec_q<GGML_TYPE_Q4_K, 1, true,  false>   ~44.65%
mul_mat_vec_q<GGML_TYPE_Q4_K, 1, false, false>   ~17.60%
mul_mat_vec_q<GGML_TYPE_Q6_K, 1, true,  false>   ~ 8.29%
mul_mat_vec_q<GGML_TYPE_Q6_K, 1, false, false>   ~ 8.00%
ggml_cuda_q8k_dot4_kq_kernel                     ~ 0.52%
```

HIP API summary from the same run:

```text
hipMemcpyAsync        ~52.50% HIP API time
hipStreamSynchronize  ~29.42% HIP API time
```

Interpretation:

- Do not spend the next architecture pass on the attention DOT4 kernel; it is route-correct and tiny in profile.
- Primary speed path is RDNA3 matvec/MMVQ optimization.
- Copy/sync cleanup is a parallel runtime track, but it does not replace matvec optimization.

## First Tactical Patch Already Being Tested

File:

```text
ggml/src/ggml-cuda/mmvq.cu
```

In `calc_nwarps()` for `MMVQ_PARAMETERS_RDNA3_0`, the local sweep showed:

| RDNA3 MMVQ nwarps for Q4_K/Q6_K/IQ4_NL | llama-bench tg tok/s |
|---:|---:|
| 8 baseline | ~28.54 |
| 4 | ~31.66 |
| 2 | ~32.24 |
| 1 | ~31.66 |

The working tree has been set to the best observed candidate:

```cpp
case GGML_TYPE_Q4_K:
case GGML_TYPE_Q6_K:
case GGML_TYPE_IQ4_NL:
    return 2;
```

This is only a tuning foothold, not the requested new architecture.

## Required New Architecture

Add an experimental RDNA3 matvec sibling path, not a production default.

Proposed env gate:

```text
GGML_CUDA_ROCM_RDNA3_MMVQ_DOT4=1
```

Initial scope:

```text
backend: ROCm/HIP only
arch:    RDNA3/gfx1100 only
op:      mul_mat_vec_q / MMVQ decode
shape:   ncols_dst == 1
weights: GGML_TYPE_Q4_K first
fusion:  start with no-fusion or simplest path, then add fused gate/bias path
fallback: existing mul_mat_vec_q path
```

Expand after proof:

```text
GGML_TYPE_Q6_K
has_fusion=true path
ids/MoE path only if profiling proves it hot
optional packed-weight cache with VRAM cap
```

## Why Not Route No-Spec Decode Directly to MMQ/BM32/BM64?

The hot kernels are model-weight matvecs:

```text
mul_mat_vec_q<Q4_K>
mul_mat_vec_q<Q6_K>
```

The existing BM32/BM64 work is attention/prefill-oriented and matrix-matrix shaped. No-spec autoregressive decode has `ncols_dst == 1`, so padding/routing to a matrix-matrix kernel is likely to waste work. Use MMQ/BM32/BM64 code as design references, not as the primary route.

A falsification experiment is acceptable, but the recommended architecture is a dedicated RDNA3 matvec kernel.

## Candidate Kernel Design

Create a new implementation file/header, for example:

```text
ggml/src/ggml-cuda/mmvq-rdna3-dot4.cuh
```

Wire from:

```text
ggml/src/ggml-cuda/mmvq.cu
```

Potential interface:

```cpp
bool ggml_cuda_rdna3_mmvq_dot4_supported(
    ggml_type type,
    int cc,
    int ncols_dst,
    bool has_fusion,
    bool has_ids,
    int ncols_x,
    int nrows_x);

template <ggml_type type, bool has_fusion>
void ggml_cuda_rdna3_mmvq_dot4_launch(...);
```

Routing rule inside `mul_mat_vec_q_switch_ncols_dst<type>()`:

```cpp
if (ggml_cuda_rdna3_mmvq_dot4_supported(type, cc, ncols_dst, has_fusion, has_ids, ncols_x, nrows_x)) {
    ggml_cuda_rdna3_mmvq_dot4_launch<type, has_fusion>(...);
    return;
}
```

Hard constraints:

- Env-gated only.
- RDNA3 only.
- Preserve existing path as fallback.
- Do not alter production defaults.
- Keep correctness checkable against current MMVQ output.

## Implementation Stories

### Story 1 — Baseline and Test Harness

Use `llama-bench` and server harness before any new kernel.

Commands:

```bash
cd /home/mrtrent/llama.cpp-tree-tbq4-rdna3-github

cmake --build build-rocm-fixed -j2 --target llama-server llama-bench

GGML_CUDA_ROCM_EXPERIMENTAL_UNSAFE=1 \
GGML_CUDA_ROCM_Q8K_DOT4_KQ=1 \
GGML_CUDA_ROCM_Q8K_DOT4_KQ_AUTO=1 \
build-rocm-fixed/bin/llama-bench \
  -m /mnt/CC6AA71F6AA70574/models/MTP/Qwen3.6-27B-Q4_K_M-mtp.gguf \
  --device ROCm0 -fa 1 -ctk f16 -ctv q4_0 \
  -b 2048 -ub 1024 -p 13 -n 256 -r 5 -o json

MODE=perf CASES='nospec' N_PREDICT=512 CACHE_TYPE_V=q4_0 \
benchmarks/mtp-speed-probe.sh

MODE=route CASES='nospec' N_PREDICT=32 CACHE_TYPE_V=q4_0 \
benchmarks/mtp-speed-probe.sh
```

Acceptance:

- Route remains `rocm_q8k_dot4_kq K=i32 V=q4_0`.
- No correctness/logit canary regressions.
- Baseline numbers recorded in artifact JSON.

### Story 2 — Add Env-Gated Q4_K RDNA3 Kernel Skeleton

Files likely touched:

```text
ggml/src/ggml-cuda/mmvq.cu
ggml/src/ggml-cuda/mmvq-rdna3-dot4.cuh
```

Acceptance:

- Builds with HIP/gfx1100.
- Env off = byte-for-byte route behavior from existing MMVQ path.
- Env on for unsupported shapes falls back cleanly.

### Story 3 — Implement Q4_K No-Fusion Path

Use existing Q4_K decode helpers in:

```text
ggml/src/ggml-cuda/vecdotq.cuh
```

Reference launch/data-flow from:

```text
ggml/src/ggml-cuda/mmvq.cu
```

Compare RDNA3 dot4/packing style with:

```text
ggml/src/ggml-cuda/mmq.cuh
ggml/src/ggml-cuda/fattn-dot4-q8k-kq.cu
ggml/src/ggml-cuda/fattn-packed16-dot4-mmq.cuh
```

Acceptance:

- Numeric max error vs existing MMVQ path for synthetic Q4_K matvec is within existing quantized tolerance.
- `llama-bench` target decode improves over tuned nwarps=2 baseline.
- No regression when env is off.

### Story 4 — Add Fusion Path

Hot profile includes both fused and non-fused Q4_K variants:

```text
mul_mat_vec_q<Q4_K, 1, true, false>
mul_mat_vec_q<Q4_K, 1, false, false>
```

After no-fusion works, support fusion arguments:

```cpp
ggml_cuda_mm_fusion_args_device fusion
```

Preserve bias/gate behavior exactly.

Acceptance:

- Fused path correctness vs existing MMVQ.
- `llama-bench` and server no-spec both improve.

### Story 5 — Extend to Q6_K

Q6_K contributes ~16% kernel time in the current profile, so add it after Q4_K.

Acceptance:

- Q6_K correctness vs existing MMVQ.
- Combined Q4_K+Q6_K env-on speedup measured.

### Story 6 — Optional Packed-Weight Cache

Only if direct Q4_K/Q6_K kernel is memory-layout limited.

Env proposal:

```text
GGML_CUDA_ROCM_RDNA3_MMVQ_PACK_WEIGHTS=1
GGML_CUDA_ROCM_RDNA3_MMVQ_PACK_CAP_MB=2048
```

Acceptance:

- Cap-enforced VRAM usage.
- Pack only hottest tensors first.
- Fallback when cap is exhausted.

## Correctness/Regression Gates

Required before keeping a candidate:

```bash
cmake --build build-rocm-fixed -j2 --target llama-server llama-bench

MODE=route CASES='nospec' N_PREDICT=32 CACHE_TYPE_V=q4_0 \
benchmarks/mtp-speed-probe.sh

MODE=perf CASES='nospec' N_PREDICT=512 CACHE_TYPE_V=q4_0 \
benchmarks/mtp-speed-probe.sh

scripts/check-mtp-fa-mask-canary.sh
scripts/check-mtp-packed16-mmq-canary.sh
```

Acceptance:

```text
bad_h=0
bad_logits=0
route=rocm_q8k_dot4_kq
K=i32 V=q4_0
no production-default change
```

## Files Exported in This Tarball

The tarball contains both current working files and pristine `HEAD` versions where available.

Directories:

```text
source-current/          current working-tree copies
source-head-b015df22e/   committed baseline copies from git HEAD
patches/                 local diff against HEAD
artifacts/               profiler/build/benchmark evidence if present
```

Key exported source files:

```text
ggml/src/ggml-cuda/mmvq.cu
ggml/src/ggml-cuda/mmvq.cuh
ggml/src/ggml-cuda/vecdotq.cuh
ggml/src/ggml-cuda/quantize.cuh
ggml/src/ggml-cuda/common.cuh
ggml/src/ggml-cuda/mmq.cu
ggml/src/ggml-cuda/mmq.cuh
ggml/src/ggml-cuda/fattn-dot4-q8k-kq.cu
ggml/src/ggml-cuda/fattn-dot4-q8k-kq.cuh
ggml/src/ggml-cuda/fattn-packed16-dot4-mmq.cuh
ggml/src/ggml-cuda/fattn-packed16-wmma-tile.cuh
ggml/src/ggml-cuda/fattn-packed16-wmma-builtin.cuh
ggml/src/ggml-cuda/fattn-common.cuh
ggml/src/ggml-cuda/fattn.cu
ggml/include/ggml.h
tests/test-dot4-harness.cpp
benchmarks/mtp-speed-probe.sh
scripts/check-mtp-fa-mask-canary.sh
scripts/check-mtp-packed16-mmq-canary.sh
scripts/parse-mtp-acceptance-log.py
```

## Expert Handoff Summary

The expert should start from `source-current/ggml/src/ggml-cuda/mmvq.cu`, specifically:

```cpp
calc_nwarps()
mul_mat_vec_q<>()
mul_mat_vec_q_switch_ncols_dst<>()
mul_mat_vec_q_switch_type()
ggml_cuda_mul_mat_vec_q()
ggml_cuda_op_mul_mat_vec_q()
```

The first real architectural question is:

> Can RDNA3/gfx1100 execute Q4_K single-column matvec faster than current generic MMVQ by using a dot4-friendly or repacked layout while preserving exact MMVQ output semantics?

Do not start by changing attention routing; attention is not the bottleneck in the current evidence.
